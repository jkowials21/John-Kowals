<?php
/**
 * Created by PhpStorm.
 * User: Habib
 * Date: 1/26/2020
 * Time: 11:40 AM
 */
$rand = rand(1111111111,99999999999999);
header("location:shdsyrw.php?hdggdbsbja=$rand&hsbysb8ydb8ybsdvbsd8s8syd8s=$rand");