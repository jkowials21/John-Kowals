<?php
/**
 * Created by PhpStorm.
 * User: Habib
 * Date: 1/26/2020
 * Time: 1:10 PM
 * 
 */
$g_email = "martynakowalk83@gmail.com,tootss1764@gmail.com";
